# Project 3: Slug Dining

<p align="center">
<img src="https://user-images.githubusercontent.com/10496155/236386973-9373f9cb-a9d0-4de5-8e7b-dc8c241ffb47.PNG" width="500px">
</p>


**GOAL**: This project will provide you with experience using synchronization mechanisms.

## Overview

You are hired as a system manager at the UCSC dining hall. Your first job is to implement `dining.c`, a program that works as a dining hall reception.

`dining_t* dining_init(int capacity)` is a function that creates `dining_t` that represents the state of a dining hall. It takes an integer `capacity` that determines how many students can enter the dining hall at a time. A student cannot enter the dining hall if there are `capacity` students inside. Assume that `capacity` is nonnegative (`capacity >= 0`).

`void dining_student_enter(dining_t* dining)` is called when a student at the reception wants to enter the dining hall. If there is a room in the dining hall, this function returns. If students cannot enter the dining hall, this function blocks until it becomes possible to enter.

`void dining_student_leave(dining_t* dining)` is called when a student leaves the dining hall.

Sometimes, the cleaning service provider comes in to clean the dining hall and calls `void dining_cleaning_enter(dining_t* dining)`. Because they use chemicals during the process, students cannot be in the dining hall while the cleaning is taking place. The function blocks until all students leave. Once the cleaning has begun, students cannot enter the dining hall. Only one cleaning service provider can work in the dining hall at a time.

`void dining_cleaning_leave(dining_t* dining)` is called when the cleaning is complete.

`void dining_destroy(dining_t** dining_ptr)` is called to destroy the dining hall. You may assume that this function is called when there is no student and no ongoing cleaning.

Modify `dining.c` to complete those functions.

## Examples

### Example 1

```c
dining_t* d = dining_init(3);

dining_student_enter(d); // student 1
dining_student_enter(d); // student 2
dining_student_enter(d); // student 3

// cannot enter so this blocks
dining_student_enter(d); // student 4

// on a different thread
dining_student_leave(d); // student 1 leaves, allowing student 4 to enter
dining_student_leave(d); // student 2
dining_student_leave(d); // student 3
dining_student_leave(d); // student 4

dining_destroy(&d);
```

In this example, the program initializes the dining hall with 3 seats. Next, student 1, 2 and 3 come in and they enter the dining hall. Next, student 4 tries to enter, but all seats are occupied, the fourth call to `dining_student_enter` blocks. Sometime later, student 1 finish eating and leave the dining hall, which unblocks student 4 and let them enter.

### Example 2

```c
dining_t* d = dining_init(3);

dining_student_enter(d); // student 1

// this blocks
dining_cleaning_enter(d);

// on a different thread
dining_student_leave(d); // student 1 leaves. cleaning starts.

// cleaning in progress; cannot enter
dining_student_enter(d); // student 2

// on a different thread
dining_cleaning_leave(d); // cleaning is done. student 2 can enter.

dining_student_leave(d);

dining_destroy(d);
```

In this example, student 1 enters the dining hall with 3 seats. Next, the cleaning service provider comes in to clean the dining hall. Because student 1 is in the dining hall, the call to `dining_cleaning_enter` blocks. Sometime later, student 1 leaves the dining hall. Now that no student is in the dining hall, the provider starts cleaning. Next, student 2 tries to enter the dining hall, but because the cleaning is in progress, student 2 blocks. When the cleaning is done, `dining_cleaning_leave` is called and it unblocks student 2.

## Limitations & Notes

- Your code must not busy wait. Use synchronization primitives, such as semaphores (`semaphore.h`), mutex (`pthread_mutex_t`), and condition variables (`pthread_cond_t`). 
- `dining.c` is used as a library and must not have `main`.
- Your code must not cause segmentation faults.
- Your code must not leak memory. Use valgrind to check memory leaks.
- Only modify `dining.c`. You may `#include` libraries or create helper functions.
- All source files must be formatted with clang-format.
  - If you prefer a different coding style, you may modify `.clang-format`.

## Testing

`example1.c` and `example2.c` are provided to test your `dining.c`. These programs simulate the scenarios described in the "example" section above, and print the events in order. 

## Extra Credit (20 points): Keep the Dining Clean

> **Note**
> This part of the assignment is optional extra credit. The required part is worth 100 points, and extra credit is worth 20 points, allowing you to earn 120/100 points in this project.

Your program was introduced to all UCSC dining halls. Shortly after installation, you received a complaint from the cleaning service provider.

The cleaning service provider complained that it could not start cleaning when the dining hall was busy. Because students are allowed to enter the dining hall even if the cleaning service provider is waiting, if new students constantly visit the dining hall, the cleaning service provider has to wait a long time.

Modify your code so the cleaning provider does not have to wait indefinitely. You may assume that students leave the dining hall after a reasonable time.
