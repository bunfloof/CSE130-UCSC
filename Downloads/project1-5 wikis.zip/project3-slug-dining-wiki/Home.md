Welcome to the project3-slug-dining wiki!
