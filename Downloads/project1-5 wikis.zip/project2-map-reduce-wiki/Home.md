Welcome to the project2-mapreduce wiki!
